
import React from "react";
import ContentGenerator from "./ContentGenerator";

function App() {
  return (
    <div className="App">
      <ContentGenerator />
    </div>
  );
}

export default App;
